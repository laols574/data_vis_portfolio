//
// a08.js
// Template for CSC444 Assignment 08
// Joshua A. Levine <josh@email.arizona.edu
//
// This file provides the template code for A08, providing a skeleton
// for how to initialize and draw the parallel coordinates plot
//



////////////////////////////////////////////////////////////////////////
// Global variables for the dataset

let data = iris;

// dims will store the four axes in left-to-right display order
let dims = [
  "sepalLength",
  "sepalWidth",
  "petalLength",
  "petalWidth"
];

// mapping from dimension id to dimension name used for text labels
let dimNames = {
  "sepalLength": "Sepal Length",
  "sepalWidth": "Sepal Width",
  "petalLength": "Petal Length",
  "petalWidth": "Petal Width",
};




////////////////////////////////////////////////////////////////////////
// Global variables for the svg

let width = dims.length*125;
let height = 500;
let padding = 50;

let svg = d3.select("#pcplot")
  .append("svg")
  .attr("width", width).attr("height", height);




////////////////////////////////////////////////////////////////////////
// Initialize the x and y scales, axes, and brushes.
//  - xScale stores a mapping from dimension id to x position
//  - yScales[] stores each y scale, one per dimension id
//  - axes[] stores each axis, one per id
//  - brushes[] stores each brush, one per id
//  - brushRanges[] stores each brush's event.selection, one per id

let xScale = d3.scalePoint()
  .domain(dims)
  .range([padding, width-padding]);

let yScales = {};
let axes = {};
let brushes = {};
let brushRanges = {};

// For each dimension, we will initialize a yScale, axis, brush, and
// brushRange
dims.forEach(function(dim) {
  //create a scale for each dimension
  yScales[dim] = d3.scaleLinear()
    .domain( d3.extent(data, function(datum) { return datum[dim]; }) )
    .range( [height-padding, padding] );

  //set up a vertical axist for each dimensions
  axes[dim] = d3.axisLeft()
    .scale(yScales[dim])
    .ticks(10);

  //set up brushes as a 20 pixel width band
  //we will use transforms to place them in the right location
  brushes[dim] = d3.brushY()
    .extent([[-10, padding], [+10, height-padding]]);

  //brushes will be hooked up to their respective updateBrush functions
  brushes[dim]
    .on("brush", updateBrush(dim))
    .on("end", updateBrush(dim))

  //initial brush ranges to null
  brushRanges[dim] = null;
});

////////////////////////////////////////////////////////////////////////
// Make the parallel coordinates plots


// add the actual polylines for data elements, each with class "datapath"
svg.append("g")
  .selectAll(".datapath")
  .data(data)
  .enter()
  .append("path")
  .attr("class", "datapath")
  .attr("stroke", function(d){
    if(d.species == "virginica"){
      return "#FF5733";
    }
    else if(d.species == "versicolor"){
      return "#FFCA33";
    }
    return "#3396FF";
  })
  .attr("fill", "none")
  .attr("opacity", ".75")
  .attr("d", path);

  // add the axis groups, each with class "axis"
  svg.selectAll(".axis")
    .data(dims).enter()
    .append("g")
    .attr("transform", function(d) { return "translate(" + xScale(d) + ")"; })
    .attr("class", "axis")
    .each(function(d) { d3.select(this).call(d3.axisLeft().scale(yScales[d])); });

  // add the axes labels, each with class "label"
  svg.selectAll(".label")
    .data(dims).enter()
    .append("g")
    .append("text")
    .attr("class", "label")
    .attr("transform", function(d) {return "translate(" + xScale(d) + ")"; })
    .style("text-anchor", "middle")
    .attr("y", 30)
    .text(function(d) { return d; })
    .style("fill", "black")
    .on("click", onClick);


  // add the brush groups, each with class ".brush"
  svg.selectAll(".brush")
    .data(dims).enter()
    .append("g")
    .attr("class", "brush")
    .attr("transform", function(d) {return "translate(" + xScale(d) + ")"; })
    .each(function(d) {
      d3.select(this).call(yScales[d].brush = brushes[d]);
    })
    .selectAll("rect")
    .attr("width", 16);



////////////////////////////////////////////////////////////////////////
// Interaction Callbacks

// Callback for swaping axes when a text label is clicked.
function onClick(d, i) {
  if(i == 0 || i == 1 || i == 2){
    temp = dims[i + 1];
    dims[i + 1] = dims[i];
    dims[i] = temp;
  }
  else{
    temp = dims[i];
    dims[i] = dims[i - 1];
    dims[i - 1] = temp;
  }

  xScale = d3.scalePoint()
    .domain(dims)
    .range([padding, width-padding]);
    console.log(xScale);

    // add the axis groups, each with class "axis"
    svg.selectAll(".axis")
      .data(dims)
      .transition()
      .duration(1000)
      .attr("transform", function(d) {return "translate(" + xScale(d) + ")"; })
      .each(function(d) { d3.select(this).call(d3.axisLeft().scale(yScales[d])); });

    // add the axes labels, each with class "label"
    svg.selectAll(".label")
      .data(dims)
      .transition()
      .duration(1000)
      .attr("transform", function(d) {return "translate(" + xScale(d) + ")"; })
      .text(function(d) { return d; })

    // add the brush groups, each with class ".brush"
    svg.selectAll(".brush")
      .data(dims)
      .transition()
      .duration(1000)
      .attr("transform", function(d) { return "translate(" + xScale(d) + ")"; })

  svg.selectAll(".datapath")
      .transition()
      .duration(1000)
      .attr("d", path);


}

// Returns a callback function that calls onBrush() for the brush
// associated with each dimension
function updateBrush(dim) {
  return function() {
    brushRanges[dim] = d3.event.selection;
    onBrush();
  };
}

// Callback when brushing to select elements in the PC plot
function onBrush() {
  let allLines = d3.selectAll(".datapath");

  function isSelected(d) {
    curr_d = d;
    curr_path = getPathCoords(path(d));

    arr = Object.keys(brushRanges);

    let allLines = d3.selectAll("path");

    exists = false;
    allLines.each(function(d,i){
      if(curr_d == d){
        exists = true;
      }
    })

    //check if in range
    within = false;
    if(exists){
      for(i = 0; i < arr.length; i++){
        curr_dim = arr[i];
        check = brushRanges[curr_dim];
        if(check != null){
          if(curr_path[i][1] < brushRanges[curr_dim][1] && curr_path[i][1] > brushRanges[curr_dim][0] ){
            within = true;
          }
          else{
            return false;
          }
        }
     }
  }
  return within;
 }

  let selected = allLines
    .filter(function(d) {
      if(isSelected(d)){
        return d;
      }
    })
    .attr("stroke", function(d){
      if(d.species == "virginica"){
        return "#FF5733";
      }
      else if(d.species == "versicolor"){
        return "#FFCA33";
      }
      return "#3396FF";
    })
    .attr("opacity", ".75");

    let nonSelected = allLines
      .filter(function(d) {
        if(!isSelected(d)){
          return d;
        }
      })
      .attr("stroke", "grey")
      .attr("opacity", ".1");

}

// Returns the path for a given data point.
function path(d) {
  return d3.line()(dims.map(function(p) { return [xScale(p), yScales[p](d[p]) ]; }));
}


//helper functions
/////////////////////////////////////////////
function getPathCoords(path){
  c = []
  coords = path.split(/(?=[LMCHV,])/);
  for(i = 0; i < coords.length; i++){
    coords[i] = Number(coords[i].replace(/[LMCHV,]/g,''));
  }
  c[0] = [coords[0], coords[1]]
  c[1] = [coords[2], coords[3]]
  c[2] = [coords[4], coords[5]]
  c[3] = [coords[6], coords[7]]

  return c
}
