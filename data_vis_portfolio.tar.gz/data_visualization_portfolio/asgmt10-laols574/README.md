A10
------------

Author: Lauren Olson [laols574](mailto:laols574@email.arizona.edu)  
Date: 4/15/20


## Notes
All four visualizations correctly render in Google Chrome.


## Included files
* a10.js - The file with all functions to create contours.
* index.html - The basic HTML template file, containing the outline of the project.
* data.js - The dataset, containing Hurricane Isabel dataset
* d3.v5.js - The D3 library.


## References
https://jalevine.bitbucket.io/csc444/lectures/2020/04/06/L21.html

