//
// a10.js
// Template for CSC444 Assignment 10
// Joshua A. Levine <josh@email.arizona.edu
//
// This file provides the template code for A10, providing a skeleton
// for how to initialize and compute isocontours
//

/*
 a10.js
 CSC444 Assignment 10
 Lauren Olson laols574@email.arizona.edu
 This file includes all functionality for
 creating and coloring the data for the requested
 visualization. There are functions for implementing the
 matching squares algorithms and handling all of its cases.
*/


////////////////////////////////////////////////////////////////////////
// Global variables, preliminaries, and helper functions

let svgSize = 490;
let bands = 49;

let xScale = d3.scaleLinear().domain([0, bands]).  range([0, svgSize]);
let yScale = d3.scaleLinear().domain([-1,bands-1]).range([svgSize, 0]);

function createSvg(sel)
{
  return sel
    .append("svg")
    .attr("width", svgSize)
    .attr("height", svgSize);
}

function createGroups(data) {
  return function(sel) {
    return sel
      .append("g")
      .selectAll("rect")
      .data(data)
      .enter()
      .append("g")
      .attr("transform", function(d) {
        return "translate(" + xScale(d.Col) + "," + yScale(d.Row) + ")";
      });
  };
}

d3.selection.prototype.callReturn = function(callable)
{
  return callable(this);
};

// This function returns the pair [min/max] for a cell d.
function gridExtent(d) {
  return [Math.min(d.NW, d.NE, d.SW, d.SE),
          Math.max(d.NW, d.NE, d.SW, d.SE)];
}



////////////////////////////////////////////////////////////////////////
// Functions for isocontouring

// Given a cell d and an isovalude value, this returns a 4-bit polarity
// signature in result.case as an integer [0,15].  Any bit that is 1
// indicates that the associate cell corner is on or above the contour.
function polarity(d, value) {
  let result = {
    NW: d.NW < value ? 0 : 1,
    NE: d.NE < value ? 0 : 1,
    SW: d.SW < value ? 0 : 1,
    SE: d.SE < value ? 0 : 1
  };
  result.case = result.NW + result.NE * 2 + result.SW * 4 + result.SE * 8;
  return result;
}

// currentContour is a global variable which stores the value
// of the contour we are currently extracting
var currentContour;

function includesOutlineContour(d) {
  let extent = gridExtent(d);
  return currentContour >= extent[0] && currentContour <= extent[1];
}

function includesFilledContour(d) {
  let extent = gridExtent(d);
  return currentContour >= extent[0];
}


function generateOutlineContour(d) {
  let wScale = d3.scaleLinear()
                 .domain([d.SW, d.NW])
                 .range([0, 10]);
  let eScale = d3.scaleLinear()
                .domain([d.SE, d.NE])
                .range([0, 10]);
  let nScale = d3.scaleLinear()
                .domain([d.NW, d.NE])
                .range([0, 10]);
  let sScale = d3.scaleLinear()
                .domain([d.SW,d.SE])
                .range([0, 10]);
/*
nw ne

sw se
(0,10) (10,10)

(0,0)  (10,0)
*/
  switch (polarity(d, currentContour).case) {
    case 0: //all vertices below isovalue
      break;

    case 1: //NW corner is above, others below
      x = nScale(currentContour);
      y = wScale(currentContour);

      return "M" + x + " 10 L0 " + y;

    case 2: //NE corner is above, others below
      x = nScale(currentContour);
      y = eScale(currentContour);

      return "M" + x + " 10 L10 " + y;

    case 3: //NE and NW corners above, others below
      y1 = wScale(currentContour);
      y2 = eScale(currentContour);

      return "M0 " + y1 + " L10 " + y2;

    case 4: //SW corner is below, others above
      x = sScale(currentContour);
      y = wScale(currentContour);

      return "M" + x + " 0 L0 " + y;

    case 5: // NE and SE
      x1 = sScale( currentContour);
      x2 = nScale(currentContour);

      return "M" + x1 + " 0 L" + x2 + " 10";

    case 6: // NW and SE
      x1 = sScale( currentContour);
      y1 = eScale(currentContour);
      x2 = nScale( currentContour);
      y2 = wScale(currentContour);

      return "M" + x1 +  " 0 L0 " + y2 + " M" + x2 +  " 10 L 10 " + y1 ;

    case 7: //se corner is above, others below
      x = sScale( currentContour);
      y = eScale(currentContour);
      return "M10 " + y + " L" + x + " 0";

    case 8: //NE corner is above, others below
      x = sScale( currentContour);
      y = eScale(currentContour);
      return "M10 " + y + " L" + x + " 0";

    case 9: //SE corner is below, others above
      x1 = sScale( currentContour);
      y1 = eScale(currentContour);
      x2 = nScale( currentContour);
      y2 = wScale(currentContour);
      //return "M 0 0 L 0 10"

      return "M" + x1 +  " 0 L0 " + y2 + " M" + x2 +  " 10 L 10 " + y1 ;

    case 10: //NE and NW corners above, donezo
      x1 = sScale( currentContour);
      x2 = nScale(currentContour);
      return "M" + x1 + " 0 L" + x2 + " 10";

    case 11: // NW and SE
      x = sScale(currentContour);
      y = wScale(currentContour);

      return "M" + x + " 0 L0 " + y;

    case 12: // NE and SE, donezo
      y1 = wScale(currentContour);
      y2 = eScale(currentContour);

      return "M0 " + y1 + " L10 " + y2;

    case 13: //NE and NW corners above, others below
      x = nScale(currentContour);
      y = eScale(currentContour);
      return "M" + x + " 10 L10 " + y;

    case 14: //SE corner is below, others above
      x = nScale(currentContour);
      y = wScale(currentContour);
      return "M" + x + " 10 L0 " + y;

    case 15:
      break;

    }
}

function generateFilledContour(d) {
  // HINT: you should set up scales which, given a contour value, can be
  // used to interpolate the function along each side in the boundary of
  // the square

  let wScale = d3.scaleLinear()
                 .domain([d.SW, d.NW])
                 .range([0, 10]);
  let eScale = d3.scaleLinear()
                .domain([d.SE, d.NE])
                .range([0, 10]);
  let nScale = d3.scaleLinear()
                .domain([d.NW, d.NE])
                .range([0, 10]);
  let sScale = d3.scaleLinear()
                .domain([d.SW,d.SE])
                .range([0, 10]);
/*
nw ne

sw se
(0,10) (10,10)

(0,0)  (10,0)
*/
  console.log(d)
  switch (polarity(d, currentContour).case) {
    case 0: //all vertices below isovalue
      return "M 0 0 L 0 10 L 10 10 L 10 0 Z"

    case 1: //NW corner is above, others below
      x = nScale(currentContour);
      y = wScale(currentContour);

      return "M" + x + " 10 L0 " + y + "L0 0 L 10 0 L 10 10 Z";

    case 2: //NE corner is above, others below
      x = nScale(currentContour);
      y = eScale(currentContour);

      return "M" + x + " 10 L10 " + y + "L 10 0 L0 0 L0 10 Z";


    case 3: //NE and NW corners above, others below
      y1 = wScale(currentContour);
      y2 = eScale(currentContour);

      return "M0 " + y1 + " L10 " + y2 + " L 10 0 L 0 0 Z";

    case 4: //SW corner is below, others above
      x = sScale(currentContour);
      y = wScale(currentContour);
      return "M" + x + " 0 L0 " + y + " L0 10 L10 10 L10 0Z";


    case 5: // NE and SE
      x1 = sScale( currentContour);
      x2 = nScale(currentContour);

      return "M" + x1 + " 0 L" + x2 + " 10 L10 10 L10 0 Z";

    case 6: // NW and SE
      x1 = sScale( currentContour);
      y1 = eScale(currentContour);
      x2 = nScale( currentContour);
      y2 = wScale(currentContour);
      //return "M 0 0 L 0 10 L 10 10 L 10 0 Z"

      return "M" + x1 +  " 0 L10 0 L10 " + y1 + " L" + x2 +  " 10 L0 10 L0 " + y2 + " Z";

    case 7: //se corner is above, others below
      x = sScale( currentContour);
      y = eScale(currentContour);

      return "M10 " + y + " L" + x + " 0" + "L 10 0 Z";

    case 8: //NE corner is above, others below
      x = sScale( currentContour);
      y = eScale(currentContour);
      return "M10 " + y + " L" + x + " 0" + "L 0 0 L0 10 L10 10Z";


    case 9: //SE corner is below, others above
      x1 = sScale( currentContour);
      y1 = eScale(currentContour);
      x2 = nScale( currentContour);
      y2 = wScale(currentContour);
      //return "M 0 0 L 0 10"

      return "M" + x1 +  " 0 L0 0 L0 " + y2 + " L" + x2 +  " 10 L10 10 L 10 " + y1 + " Z";

    case 10: //NE and NW corners above, donezo
      x1 = sScale( currentContour);
      x2 = nScale(currentContour);

      return "M" + x1 + " 0 L" + x2 + " 10 L0 10 L0 0 Z";

    case 11: // NW and SE
      x = sScale(currentContour);
      y = wScale(currentContour);

      return "M" + x + " 0 L0 " + y + "L 0 0 Z";

    case 12: // NE and SE, donezo
      y1 = wScale(currentContour);
      y2 = eScale(currentContour);

      return "M0 " + y1 + " L10 " + y2 + " L 10 10 L 0 10 Z";

    //????
    case 13: //NE and NW corners above, others below
      x = nScale(currentContour);
      y = eScale(currentContour);

      return "M" + x + " 10 L10 " + y + "L 10 10 Z";


    case 14: //SE corner is below, others above
      x = nScale(currentContour);
      y = wScale(currentContour);

      return "M" + x + " 10 L0 " + y + "L0 10 Z";

    case 15:
      break;

    }
}



////////////////////////////////////////////////////////////////////////
// Visual Encoding portion that handles the d3 aspects


// d3 function to compute isocontours for all cells that span given a
// range of values, [minValue,maxValues], this function produces a set
// of size "steps" isocontours to be added to the selection "sel"
function createOutlinePlot(minValue, maxValue, steps, sel)
{
  let contourScale = d3.scaleLinear().domain([1, steps]).range([minValue, maxValue]);
  for (let i=1; i<=steps; ++i) {
    currentContour = contourScale(i);
    sel.filter(includesOutlineContour).append("path")
      .attr("transform", "translate(0, 10) scale(1, -1)") // ensures that positive y points up
      .attr("d", generateOutlineContour)
      .attr("fill", "none")
      .attr("stroke", "black");
  }
}

// d3 function to compute filled isocontours for all cells that span
// given a range of values, [minValue,maxValues], this function produces
// a set of size "steps" isocontours to be added to the selection "sel".
// colorScale is used to assign their fill color.
function createFilledPlot(minValue, maxValue, steps, sel, colorScale)
{
  let contourScale = d3.scaleLinear().domain([1, steps]).range([minValue, maxValue]);
  for (let i=steps; i>=1; --i) {
    currentContour = contourScale(i);
     sel.filter(includesFilledContour).append("path")
      .attr("transform", "translate(0, 10) scale(1, -1)") // ensures that positive y points up
      .attr("d", generateFilledContour)
      .attr("fill", function(d) { return colorScale(currentContour); });
  }
}

// Compute the isocontour plots
let plot1T = d3.select("#plot1-temperature")
    .callReturn(createSvg)
    .callReturn(createGroups(temperatureCells));
let plot1P = d3.select("#plot1-pressure")
    .callReturn(createSvg)
    .callReturn(createGroups(pressureCells));

createOutlinePlot(-70, -60, 10, plot1T);
createOutlinePlot(-500, 200, 10, plot1P);

// Compute the filled isocontour plots
let plot2T = d3.select("#plot2-temperature")
    .callReturn(createSvg)
    .callReturn(createGroups(temperatureCells));
let plot2P = d3.select("#plot2-pressure")
    .callReturn(createSvg)
    .callReturn(createGroups(pressureCells));

createFilledPlot(-70, -60, 10, plot2T,
              d3.scaleLinear()
                .domain([-70, -60])
                .range(["blue", "red"]));
createFilledPlot(-500, 200, 10, plot2P,
              d3.scaleLinear()
                .domain([-500, 0, 500])
                .range(["#ca0020", "#f7f7f7", "#0571b0"]));
