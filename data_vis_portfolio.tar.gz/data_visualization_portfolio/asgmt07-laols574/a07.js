//
// a07.js
// Skeleton for CSC444 Assignment 07
// Joshua A. Levine <josh@email.arizona.edu
//
// This file provides the skeleton code for you to write for A07.  It
// provides partial implementations for a number of functions you will
// implement to visualize scatteplots of the iris dataset with joint
// interactions
//
// Your main task is to complete the functions:
// (1) makeScatterplot(), which is used to generically create plots
// (2) onBrush(), which is the callback used to interact
//
// You will also need to implement the logic for responding to selection
//

/*
 a07.js
 CSC444 Assignment 07
 Lauren Olson <laols574@email.arizona.edu
 This file includes all functionality for
 creating and coloring the data for the requested
 visualization. There are functions for creating the various
 scales as well as a function for creating the vis as a whole.
 There is also implemetation of the linking and brushing functions.
*/

////////////////////////////////////////////////////////////////////////
// Global variables for the dataset and brushes

let data = iris;

// brush1 and brush2 will store the extents of the brushes,
// if brushes exist respectively on scatterplot 1 and 2.
//
// if either brush does not exist, brush1 and brush2 will
// hold the null value.

let brush1 = null;
let brush2 = null;


////////////////////////////////////////////////////////////////////////
// xAccessor and yAccessor allow this to be generic to different data
// fields


/*
 makeScatterplot
 input:
 sel - svg element, xAccessor - x values, yAccessor - y values
 This function creates a scatterplot based on the inputted x and y values
 It uses scaling and includes allows buttons, when clicked on, to be linked
 and to provide table data
*/
function makeScatterplot(sel, xAccessor, yAccessor)
{
  let width = 500;
  let height = 500;

  let svg = sel
    .append("svg")
    .attr("width", width).attr("height", height);

  let xScale = d3.scaleLinear()
        .domain([d3.min(xAccessor), d3.max(xAccessor)])
        .range([65, width - 65]);

  let yScale = d3.scaleLinear()
        .domain([d3.min(yAccessor), d3.max(yAccessor)])
        .range([height - 65, 65]);

  let brush = d3.brush();

  svg.append("g")
    .attr("class", "brush")
    .call(brush);


  let circles = svg.append("g")
    .selectAll("circle")
    .data(iris)
    .enter()
    .append("circle")
    .attr("cx", function(d, i){
      return xScale(xAccessor[i]);
    }
    )
    .attr("cy", function(d, i){
      return yScale(yAccessor[i]);})
    .attr("r", 8)
    .attr("stroke", "white")
    .attr("fill", function(d){
        if(d.species == "virginica"){
          return "#FF5733";
        }
        else if(d.species == "versicolor"){
          return "#FFCA33";
        }
        return "#3396FF";
      }
    )
    .on("click", function(d, i){
        var old = d;

        addTable(d);

        d3.selectAll("circle").attr("r", 8);

        d3.select(this).attr("r", 12);

        s = isFirstPlot(xAccessor);

        if(s){
          d3.select("#scatterplot_2")
            .selectAll("circle")
            .data(iris)
            .attr("r", function(d){
              if(d == old){
                return 12;
              }
              else{
                return 8;
              }
            });

        }
        else{
          //first plot
          d3.select("#scatterplot_1")
          .selectAll("circle")
          .data(iris)
          .attr("r", function(d){
            if(d == old){
              return 12;
            }
            else{
              return 8;
            }
          });
        }
    }
    );


  //axes
  let xAxis = d3.axisBottom().scale(xScale);


  let yAxis = d3.axisLeft().scale(yScale);

  svg.append("g")
    .attr("transform", "translate(5, 455)")
    .call(xAxis);

  svg.append("g")
  .attr("transform", "translate(50, 5)")
    .call(yAxis);

  //axes labels
  svg.append("text")
    .attr("transform",
          "translate(" + (270) + " ," +
                         (490) + ")")
    .style("text-anchor", "end")
    .text(function(){
      if(isFirstPlot(xAccessor)){
        return "Sepal Length";
      }
      else{
        return "Petal Length";
      }
    });

  svg.append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", 5)
    .attr("x",-280)
    .attr("dy", "1em")
    .style("text-anchor", "middle")
    .text(function(){
      if(isFirstPlot(xAccessor)){
        return "Sepal Width";
      }
      else{
        return "Petal Width";
      }
    });

  // finally, return a plot object for global use in the brushes,
  // feel free to change this interface
  return {
    svg: svg,
    brush: brush,
    xScale: xScale,
    yScale: yScale
  };
}

////////////////////////////////////////////////////////////////////////
//helper functions
/*
 isFirstPlot
 input:
 xAccessor - x values,
 This function indicates wheether the current scatterplot is the first or the
 second one created, only really useful for this specific example
*/
function isFirstPlot(xAccessor){
  j = 0;
  for(i = 0; i < xAccessor.length; i++){
    j += xAccessor[i];
  }

  t = j / xAccessor.length;
  return t == 5.843333333333335;
}

/*
 addTable
 input:
 d - data element, object in iris,
 This function adds the object data to the table
*/
function addTable(d){
  sepalLength = document.getElementById("table-sepalLength").innerHTML = d.sepalLength;

  sepalWidth = document.getElementById("table-sepalWidth").innerHTML =  d.sepalWidth

  petalLength = document.getElementById("table-petalLength").innerHTML =  d.petalLength

  petalWidth = document.getElementById("table-petalWidth").innerHTML =  d.petalWidth

  species = document.getElementById("table-species").innerHTML =  d.species
}

////////////////////////////////////////////////////////////////////////
// Setup plots

//create arrays with proper values to be used ass xAccessor and yAccessor
var sl_arr = [];
for(i = 0; i < iris.length; i++){
  sl_arr[i] = iris[i].sepalLength;
}

var sw_arr = [];
for(i = 0; i < iris.length; i++){
  sw_arr[i] = iris[i].sepalWidth;
}

var pl_arr = [];
for(i = 0; i < iris.length; i++){
  pl_arr[i] = iris[i].petalLength;
}

var pw_arr = [];
for(i = 0; i < iris.length; i++){
  pw_arr[i] = iris[i].petalWidth;
}

plot1 = makeScatterplot(d3.select("#scatterplot_1"),
                        sl_arr,
                        sw_arr);
plot2 = makeScatterplot(d3.select("#scatterplot_2"),
                        pl_arr,
                        pw_arr);

////////////////////////////////////////////////////////////////////////
// Callback during brushing
/*
 onBrush
 input:
 none
 This function controls what happens when the user "brushes", aka creates a
 dragged box on the plot
*/
function onBrush() {
  let allCircles = d3.select("body").selectAll("circle").attr("stroke", "white");;
  if (brush1 === null && brush2 === null) {
    return;
  }

  // Selection filter function
  /*
   isSelected
   input:
    d - data element, object in iris,
   This function returns whether or not an item is within the selected region
  */
  function isSelected(d) {
    var item = d;
    if(brush1 != null && brush2 == null){
      allCircles = d3.select("#scatterplot_1").selectAll("circle")
      x1 = brush1[0][0]
      x2 = brush1[1][0]
      y1 = brush1[0][1]
      y2 = brush1[1][1]
    }
    else if(brush2 != null && brush1 == null){
      allCircles = d3.select("#scatterplot_2").selectAll("circle")
      x1 = brush2[0][0]
      x2 = brush2[1][0]
      y1 = brush2[0][1]
      y2 = brush2[1][1]
    }
    ret = false;
    allCircles.each(function(d,i){
      if(d3.select(this).attr("cx") > x1 && d3.select(this).attr("cx") < x2 && d3.select(this).attr("cy") < y2 && d3.select(this).attr("cy") > y1){
        if(item == d){
          ret = true;
        }
      }
    }
    )
    return ret;
  }

  let selected = allCircles
    .filter(function(d) {
      if(isSelected(d)){
        return d;
      }
    })
    .attr("stroke", "black");

}

////////////////////////////////////////////////////////////////////////
//
// d3 brush selection
//
// The "selection" of a brush is the range of values in either of the
// dimensions that an existing brush corresponds to. The brush selection
// is available in the d3.event.selection object.
//
//   e = d3.event.selection
//   e[0][0] is the minimum value in the x axis of the brush
//   e[1][0] is the maximum value in the x axis of the brush
//   e[0][1] is the minimum value in the y axis of the brush
//   e[1][1] is the maximum value in the y axis of the brush
//
// The most important thing to know about the brush selection is that
// it stores values in *PIXEL UNITS*. Your logic for highlighting
// points, however, is not based on pixel units: it's based on data
// units.
//
// In order to convert between the two of them, remember that you have
// the d3 scales you created with the makeScatterplot function above.
//
// It is not necessary to use, but you might also find it helpful to
// know that d3 scales have a function to *invert* a mapping: if you
// create a scale like this:
//
//  s = d3.scaleLinear().domain([5, 10]).range([0, 100])
//
// then s(7.5) === 50, and s.invert(50) === 7.5. In other words, the
// scale object has a method invert(), which converts a value in the
// range to a value in the domain. This is exactly what you will need
// to use in order to convert pixel units back to data units.
//
//
// NOTE: You should not have to change any of the following:

function updateBrush1() {
  brush1 = d3.event.selection;
  onBrush();
}

function updateBrush2() {
  brush2 = d3.event.selection;
  onBrush();
}

plot1.brush
  .on("brush", updateBrush1)
  .on("end", updateBrush1);

plot2.brush
  .on("brush", updateBrush2)
  .on("end", updateBrush2);
