A07 README
------------

Author: Lauren Olson [laols574](mailto:laols574@email.arizona.edu)  
Date: 3/18/2020


## Notes
Graphs are rendering properly in Chrome. Brushing and linking is working in Chrome.


## Included files

* a07.js - contains all functionality for creating graphs, linking and brushing
* index.html - contains the html template for d3 objects
* iris.js - contains all data
* d3.v5.js - d3 functions


## References
Troubleshooting:
https://stackoverflow.com/questions/36356201/filter-nodes-by-weight-and-change-attribute
https://stackoverflow.com/questions/43646573/d3-get-attributes-from-element
https://github.com/d3/d3-selection
https://observablehq.com/@d3/mona-lisa-histogram
https://bl.ocks.org/johnnygizmo/3d593d3bf631e102a2dbee64f62d9de4

