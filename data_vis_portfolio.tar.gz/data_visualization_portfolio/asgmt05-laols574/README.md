A05
------------

Author: Lauren Olson [laols574](mailto:laols574@email.arizona.edu)  
Date: 2/24/20


## Notes
This file was rendering correctly in Google Chrome. All three buttons, as 
well as the two extra buttons for the extra credit, were providing accurate
transitions.


## Included files

* index.html - This file contains the HTML for the project. Its elements
are the ones manipulated in order to present visualizations. 
* a05.js - This file contains all the functions necessary to produce the 
visualization, including the coloring and scaling. 
* buttons.js - This file contains all the functionality necessary for 
creating the buttons as well as the functions to change the visualization
behavior. 
* d3.v5.js - all d3 functions
* calvinScores.js - the data 


## References
For scales: 
- https://github.com/d3/d3-scale#scaleQuantize
- https://github.com/d3/d3-scale#continuous_domain
- https://www.tutorialsteacher.com/d3js/scales-in-d3

For transitions:
- https://github.com/d3/d3-transition
