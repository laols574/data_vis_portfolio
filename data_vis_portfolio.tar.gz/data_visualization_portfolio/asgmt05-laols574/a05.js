/*
 index.html
 CSC444 Assignment 05
 Lauren Olson <laols574@email.arizona.edu
 This file includes all functionality for
 creating and coloring the data for the requested
 visualization. There are functions for creating the various
 scales as well as a function for creating the vis as a whole.
*/

/*
 Script to clamp
 This function adds the utility to round down values
 and also scale them based on the ukDriverFatalities data
*/
function clamp(v) {
  return Math.floor(Math.max(0, Math.min(255, v)));
}

/*
 Script to rgb
 This function adds the utility to change integer values
 into a rgb string to feed into a d3 attr function
*/

function rgb(r, g, b) {
  return "rgb(" + r + "," + g + "," + b + ")";
}

/*
 Script for color1
 This function also scales data values to color
 based on the gpa scores data
 - minimum values are blue and max are red
*/
function color1(){
          var gpa_arr = [];
          for(i = 0; i < scores.length; i++){
            gpa_arr[i] = scores[i].GPA;
          }
          return d3.scaleLinear()
                  .domain([d3.min(gpa_arr), d3.max(gpa_arr)])
                  .range(["blue", "red"]);
}
/*
 Script for color2
 This function also scales data values to color
 based on the gpa scores data
 - the color is scaled to the data continuously
 and connected to three different colors at the
 min, median and max positions

*/
function color2(){
          var gpa_arr = [];
          for(i = 0; i < scores.length; i++){
            gpa_arr[i] = scores[i].GPA;
          }
          return d3.scaleLinear()
                  .domain([d3.min(gpa_arr), d3.mean(gpa_arr), d3.max(gpa_arr)])
                  .range(["#2c7bb6", "#ffffbf", "#d7191c"]);
}

/*
 Script for color3
 This function also scales data values to color
 based on the gpa scores data
 - this scale quantizes the data to 5 different colors
*/
function color3(){
          var gpa_arr = [];
          for(i = 0; i < scores.length; i++){
            gpa_arr[i] = scores[i].GPA;
          }
          return d3.scaleQuantize()
                  .domain([d3.min(gpa_arr), d3.max(gpa_arr)])
                  .range(["#d7191c", "#fdae61", "#ffffbf", "#abd9e9", "#2c7bb6"]);
}

/*
 Script for cxScale
 Creates a linear scale for the cx position
 based on the SATM data
*/
function cxScale(){
    var satm_arr = [];
    for(i = 0; i < scores.length; i++){
      satm_arr[i] = scores[i].SATM;
    }
    return d3.scaleLinear()
              .domain([d3.min(satm_arr), d3.max(satm_arr)])
              .range([60, 400]);
}

/*
 Script for cxCumScale
 Creates a linear scale for the cx position
 based on the SATM + SATV data
*/
function cxCumScale(){
    var satm_arr = [];
    for(i = 0; i < scores.length; i++){
      satm_arr[i] = scores[i].SATM + scores[i].SATV;
    }
    return d3.scaleLinear()
              .domain([d3.min(satm_arr), d3.max(satm_arr)])
              .range([60, 400]);
}

/*
 Script for cyScale
 Creates a linear scale for the cy position
 based on the ACT data
*/
function cyScale(){
    var act_arr = [];
    for(i = 0; i < scores.length; i++){
      act_arr[i] = scores[i].ACT;
    }

    return d3.scaleLinear()
              .domain([d3.min(act_arr), d3.max(act_arr)])
              .range([400, 55]);
}

/*
 Script for cxScale
 Creates a linear scale for the radius position
 based on the SATV data
*/
function rScale(){
    var satv_arr = [];
    for(i = 0; i < scores.length; i++){
      satv_arr[i] = scores[i].SATV;
    }
    return d3.scaleSqrt()
              .domain([d3.min(satv_arr), d3.max(satv_arr)])
              .range([2, 12]);
}

/*
 Script to create a visualization 1
 First, this script identifies the first svg
 element via it's id. Next, it creates the required
 variables. This function utilizes d3 functions to
 create elements through the enter() function. Data is
 bound to the svg element, attributes are chosen, and
 the proper elements are appended to the svg canvas.
*/

function createVis1(){
  let d = scores;
  let vis1 = d3.select("#vis1")
              .append("svg")
              .attr("id", "scatterplot_1")
              .attr("width", "500")
              .attr("height", "500");


  vis1.selectAll("whatever")
        .data(d)
        .enter()
        .append("circle")
        .attr("cx", function(d){
          cx = cxScale();
          return cx(d.SATM);})
        .attr("cy", function(d){
          cy = cyScale();
          return  cy(d.ACT);})
        .attr("r", function(d){
          r = rScale();
          return r(d.SATV);})
        .attr("fill", function(d){
            c = color1();
            return c(d.GPA);}
        );

    //code for the axes
    var satm_arr = [];
    for(i = 0; i < scores.length; i++){
      satm_arr[i] = scores[i].SATM;
    }

    var act_arr = [];
    for(i = 0; i < scores.length; i++){
      act_arr[i] = scores[i].ACT;
    }

    var xScale = d3.scaleLinear()
              .domain([d3.min(satm_arr), d3.max(satm_arr)])
              .range([50, 450]);

    var yScale = d3.scaleLinear()
              .domain([d3.min(act_arr), d3.max(act_arr)])
              .range([450, 50]);

    let xAxis = d3.axisBottom()
      .scale(xScale);

    let yAxis = d3.axisLeft()
      .scale(yScale);

    vis1.append("g")
       .attr("transform", "translate(5, 455)")
       .call(xAxis);

     vis1.append("g")
        .attr("transform", "translate(50, 5)")
        .call(yAxis);

    vis1.append("text")
        .attr("transform",
              "translate(" + (270) + " ," +
                             (500) + ")")
        .style("text-anchor", "end")
        .text("SATM");

    vis1.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 10)
        .attr("x",-270)
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .text("ACT");

}
