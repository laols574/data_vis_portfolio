//
// a12.js
// Template code for CSC444 Assignment 12
// Joshua A. Levine <josh@email.arizona.edu
//
// This file provides a template skeleton for visualization vector
// fields using color mapping and glyphs
//
//

/*
 a11.js
 CSC444 Assignment 12
 Lauren Olson laols574@email.arizona.edu
 This file includes all functionality for
 creating  the four flow visualizations.
*/


////////////////////////////////////////////////////////////////////////
// Global variables, preliminaries

let svgSize = 510;
let bands = 50;

let xScale = d3.scaleLinear().domain([0,bands]).range([5, svgSize-5]);
let yScale = d3.scaleLinear().domain([0,bands]).range([svgSize-5, 5]);

function createSvg(sel)
{
  return sel
    .append("svg")
    .attr("width", svgSize)
    .attr("height", svgSize);
}

function createGroups(data) {
  return function(sel) {
    return sel
      .append("g")
      .selectAll("*")
      .data(data)
      .enter()
      .append("g")
      .attr("transform", function(d) {
        return "translate(" + xScale(d.Col) + "," + yScale(d.Row) + ") scale(1, -1)";
      });
  };
}

d3.selection.prototype.callReturn = function(callable)
{
  return callable(this);
};

////////////////////////////////////////////////////////////////////////
// PART 1
mag_arr = []
for(i = 0; i < data.length; i++){
  y = data[i].vy;
  x = data[i].vx;
  mag_arr[i] = magnitude(x,y);
}

magColorScale = d3.scaleSequential(d3.interpolatePiYG)
                   .domain([d3.min(mag_arr), d3.max(mag_arr)]);

let magColor = d3.select("#plot-color")
        .callReturn(createSvg)
        .callReturn(createGroups(data));

magColor.append("rect")
        .attr("x", function(d){return d.Col+10;})
        .attr("y", function(d){return d.Row+10;})
        .attr("height", 11)
        .attr("width", 11)
        .attr("fill", function(d){
          mag = magnitude(d.vx, d.vy);
          return magColorScale(mag);
        });

function magnitude(x, y){
  x2 = x*x;
  y2 = y*y;
  return Math.sqrt(x2 + y2);
}
////////////////////////////////////////////////////////////////////////
// PART 2

let lineGlyph = d3.select("#plot-line")
        .callReturn(createSvg)
        .callReturn(createGroups(data));


// WRITE THIS PART
lineGlyph.append("line")
          .attr("x1",0)
          .attr("x2", 10)
          .attr("y1", 5)
          .attr("y2", 5)
          .attr("transform", function(d, i){
            return "rotate(" + Math.atan2(d.vy, d.vx) * 180 / Math.PI  + " 5 5)";

          })
        .attr("stroke", "black")
        ;

////////////////////////////////////////////////////////////////////////
// PART 3

let uniformGlyph = d3.select("#plot-uniform")
        .callReturn(createSvg)
        .callReturn(createGroups(data));

magScale = d3.scaleLinear()
             .domain([d3.min(mag_arr), d3.max(mag_arr)])
             .range([3,0]);


uniformGlyph.append('defs')
  .append('marker')
  .data(data)
  .attr('markerWidth', 5)
  .attr('markerHeight', 5)
  .attr("id", function(d,i){
    return "arrow_" + d.Col + "_" + d.Row;
  })
  .attr('refX', function(d,i){
    ret = magScale(magnitude(d.vx, d.vy));

    return ret;
  })
  .attr("refY", 3)
  .attr("orient", "auto")
  .append("path")
  .attr("d", "M0,0 L5,2.5 L0,5 Z")
  .attr("fill", "black")
  .attr("transform", "scale(1 1)")
;

uniformGlyph.append("path")
  .attr("d",function(d, i){
    ret = magScale(magnitude(d.vx, d.vy));
    return "M" + ret + " 5 L" + (10-ret) + " 5";
  })
  .attr("transform", function(d, i){
    angle = Math.atan2(d.vy, d.vx) * 180 / Math.PI ;
    return "rotate(" + angle + ")";
  })
  .attr("stroke", "black")
  .style("marker-end", function(d,i){return "url(#arrow_" + d.Col + "_" + d.Row + ")";});


////////////////////////////////////////////////////////////////////////
// PART 4
magScale2 = d3.scaleLinear()
             .domain([d3.min(mag_arr), d3.max(mag_arr)])
             .range([5,10]);

let randomGlyph = d3.select("#plot-random")
        .callReturn(createSvg)
        .callReturn(createGroups(data));

randomGlyph.append('defs')
  .append('marker')
  .data(data)
  .attr('markerWidth', 5)
  .attr('markerHeight', 5)
  .attr("id", function(d,i){
    return "arrow_" + d.Col + "_" + d.Row + "_";
  })
  .attr('refX', function(d,i){
    ret = magScale(magnitude(d.vx, d.vy));

    return ret;
  })
  .attr("refY", 3)
  .attr("orient", "auto")
  .append("path")
  .attr("d", "M0,0 L5,2.5 L0,5 Z")
  .attr("fill", function(d){
    mag = magnitude(d.vx, d.vy);
    return magColorScale(mag);
  })
  .attr("transform", "scale(1 1)")
;



randomGlyph.append("path")
  .attr("d",function(d, i){
    random = (Math.random() * 10)/2
    ret = magScale(magnitude(d.vx, d.vy));
    return "M" + ret + " "+ random + " L" + (10-ret) + " " + random;
  })
  .attr("transform", function(d, i){
    angle = Math.atan2(d.vy, d.vx) * 180 / Math.PI ;
    return "rotate(" + angle + ")";
  })
  .attr("stroke", function(d){
    mag = magnitude(d.vx, d.vy);
    return magColorScale(mag);
  })
  .style("marker-end", function(d,i){return "url(#arrow_" + d.Col + "_" + d.Row + "_)";});
