Template for A11
------------

Author: Lauren Olson [laols574](mailto:laols574@email.arizona.edu)  
Date: 5/4/2020


## Notes
All visualizations are correctly rendering in Google Chrome.


## Included files

* a12.js - This file contains all of the functionality for creating the visualizations
* d3.v5.js - This file contains D3.
* index.html - This is the HTML file which acts as a template for the visualization.
* data.js - Contains the flow data.


## References
for the markers:
http://bl.ocks.org/dustinlarimer/5888271

https://blockbuilder.org/anees715/72d4293c3ccbae8d272260586d21cc4c

http://jsfiddle.net/Tymek/9nbwS/

for the rotation:
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/atan2
