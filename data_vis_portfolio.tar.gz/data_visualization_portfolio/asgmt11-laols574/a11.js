//
// a11.js
// Template code for CSC444 Assignment 11
// Joshua A. Levine <josh@email.arizona.edu
//
// This implements an editable transfer function to be used in concert
// with the volume renderer defined in volren.js
//
// It expects a a div with id 'tfunc' to place the d3 transfer function
// editor
//

/*
 a11.js
 CSC444 Assignment 11
 Lauren Olson laols574@email.arizona.edu
 This file includes all functionality for
 creating  the visualization. There are functions for
 implementing the transfer function, the buttons, the colorbar
 and the curve.
*/

////////////////////////////////////////////////////////////////////////
// Global variables and helper functions

// colorTF and opacityTF store a list of transfer function control
// points.  Each element should be [k, val] where k is a the scalar
// position and val is either a d3.rgb or opacity in [0,1]
let colorTF = [];
let opacityTF = [];

// D3 layout variables
let size = 500;
let svg = null;

// Variables for the scales
let xScale = null;
let yScale = null;
let colorScale = null;



////////////////////////////////////////////////////////////////////////
// Visual Encoding portion that handles the d3 aspects

// Function to create the d3 objects
function initializeTFunc() {
  svg = d3.select("#tfunc")
    .append("svg")
    .attr("width", size)
    .attr("height", size);

  //Initialize the axes
  xScale = d3.scaleLinear()
             .domain([dataRange[0], dataRange[1]])
             .range([10, size - 15]);

  yScale = d3.scaleLinear()
              .domain([0, 1])
              .range([size - 41, 10]);

  xAxis = d3.axisBottom().scale(xScale);

  yAxis = d3.axisLeft().scale(yScale);

  svg.append("g")
      .attr("class", "xaxis")
      .attr("transform", "translate(5, 455)")
      .call(xAxis);

  svg.append("g")
      .attr("class", "yaxis")
      .attr("transform", "translate(23, -5)")
      .call(yAxis);


  //Initialize circles for the opacity TF control points
  let drag = d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended);

  var focus = svg.append("g")
    .attr("class", "points")
    .selectAll("circle")
    .data(opacityTF)
    .enter()
    .append("circle")
    .attr("index", (d,i) => i)
    .style('cursor', 'pointer')
    .call(drag);

    //Initialize path for the opacity TF curve
    svg.selectAll("whatever")
      .data(opacityTF)
      .enter()
      .append("path")
      .attr("class", "datapath")
      .attr("stroke", "black")
      .attr("fill", "none")
      .attr("d", function(d,i){
        first = i - 1;
        if(first < 0){return;}
        x1 = (i - 1)*56 + 23;
        y1 = yScale(opacityTF[first][1]);
        x2 = i*56 + 23;
        y2 = yScale(d[1]);

        return "M" + x1 + " " + y1 + " L" + x2 + " " + y2 ;
      });

  //Create the color bar to show the color TF
  svg.selectAll("whatever")
    .data(colorTF)
    .enter()
    .append("rect")
    .attr("fill", function(d){
      return d[1];
    });

  //After initializing, set up anything that depends on the TF arrays
  updateTFunc();
}

// Call this function whenever a new dataset is loaded or whenever
// colorTF and opacityTF change

function updateTFunc() {
  //update scales
  //Initialize the axes
  xScale = d3.scaleLinear()
             .domain([dataRange[0], dataRange[1]])
             .range([10, size - 15]);

  yScale = d3.scaleLinear()
              .domain([0, 1])
              .range([size - 41, 10]);

  xAxis = d3.axisBottom().scale(xScale);

  yAxis = d3.axisLeft().scale(yScale);

  svg.select(".xaxis")
      .attr("transform", "translate(5, 455)")
      .call(xAxis);

  svg.select(".yaxis")
      .attr("transform", "translate(23, -5)")
      .call(yAxis);


  //Initialize path for the opacity TF curve
  svg.selectAll(".datapath")
    .data(opacityTF)
    .attr("d", function(d,i){
      first = i - 1;
      if(first < 0){return;}
      x1 = (i - 1)*56 + 23;
      y1 = yScale(opacityTF[first][1]);
      x2 = i*56 + 23;
      y2 = yScale(d[1]);

      return "M" + x1 + " " + y1 + " L" + x2 + " " + y2 ;
    });


  //update opacity curves
  d3.select(".points")
    .selectAll("circle")
    .data(opacityTF)
    .attr("stroke", "black")
    .attr("fill", function(d, i){return colorTF[i][1];})
    .attr("cx", function(d, i){return i*56 + 23;})
    .attr("cy", function(d, i){ return yScale(d[1]);})
    .attr("r", 5);

  //update colorbar
  svg.selectAll("whatever")
    .data(colorTF)
    .enter()
    .append("rect")
    .attr("x", function(d,i) {return i*56})
    .attr("y" , 475)
    .attr("width", 56)
    .attr("height", 25)
    .attr("fill", function(d){
      return d[1];
    });
}


// To state, let's reset the TFs and then initialize the d3 SVG canvas
// to draw the default transfer function

resetTFs();
initializeTFunc();


////////////////////////////////////////////////////////////////////////
// Interaction callbacks

// Will track which point is selected
let selected = null;

// Called when mouse down
function dragstarted() {
  selected = parseInt(d3.select(this).attr("index"));
}

// Called when mouse drags
function dragged() {
  if (selected != null) {
    let pos = [];
    pos[0] = xScale.invert(d3.event.x);
    pos[1] = yScale.invert(d3.event.y);

    if(pos[0] > dataRange[1]){
      pos[0] = dataRange[1];
    }
    if(pos[0] < dataRange[0]){
      pos[0] = dataRange[0];
    }
    if(pos[1] < 0 ){
      pos[1] = 0;
    }
    if(pos[1] > 1){
      pos[1] = 1;
    }

    opacityTF[selected] = pos;

    //update TF window
    updateTFunc();

    //update volume renderer
    updateVR(colorTF, opacityTF);
  }
}

// Called when mouse up
function dragended() {
  selected = null;
}

////////////////////////////////////////////////////////////////////////
// Function to read data

// Function to process the upload
function upload() {
  if (input.files.length > 0) {
    let file = input.files[0];
    console.log("You chose", file.name);

    let fReader = new FileReader();
    fReader.readAsArrayBuffer(file);

    fReader.onload = function(e) {
      let fileData = fReader.result;

      //load the .vti data and initialize volren
      initializeVR(fileData);

      //upon load, we'll reset the transfer functions completely
      resetTFs();

      //Update the tfunc canvas
      updateTFunc();

      //update the TFs with the volren
      updateVR(colorTF, opacityTF, false);
    }
  }
}

// Attach upload process to the loadData button
var input = document.getElementById("loadData");
input.addEventListener("change", upload);



////////////////////////////////////////////////////////////////////////
// Function to respond to buttons that switch color TFs

function resetTFs() {
  makeSequential();
  makeOpacity();
}

// Make a default opacity TF
function makeOpacity() {

  opacityScale = d3.scaleLinear()
                   .domain([dataRange[0], dataRange[1]])
                   .range([0, 1]);
   opacityTF = [];
   for(i = 1; i <= 9; i++){
     val = (dataRange[1]*i)/9;
     opacityTF[i - 1] = [val, opacityScale(val)];
   }

}

// Make a diverging color TF
function makeDiverging() {
  colorScale = d3.scaleSequential(d3.interpolatePiYG)
                     .domain([dataRange[0], dataRange[1]]);

  colorTF = [];
  for(i = 1; i <= 9; i++){
    val = (dataRange[1]*i)/9;
    colorTF[i - 1] = [val, d3.rgb(colorScale(val))];
  }

}

// Make a categorical color TF
function makeCategorical() {
  colorScale = d3.scaleOrdinal(d3.schemeTableau10)
                     .domain([dataRange[0], dataRange[1]]);

   colorTF = [];
   for(i = 1; i <= 10; i++){
     val = (dataRange[1]*i)/10;
     colorTF[i - 1] = [val, d3.rgb(colorScale(val))];
   }
}
// Make a sequential color TF
function makeSequential() {
  colorScale = d3.scaleOrdinal(d3.schemeOranges[9])
              .domain([dataRange[0], dataRange[1]]);
  //Here is a default TFs
  colorTF = [];
  for(i = 1; i <= 9; i++){
    val = (dataRange[1]*i)/9;
    colorTF[i - 1] = [val, d3.rgb(colorScale(val))];
  }


}



// Configure callbacks for each button
d3.select("#sequential").on("click", function() {
  makeSequential();
  updateTFunc();
  updateVR(colorTF, opacityTF, false);
});

d3.select("#diverging").on("click", function() {
  makeDiverging();
  updateTFunc();
  updateVR(colorTF, opacityTF, false);
});

d3.select("#categorical").on("click", function() {
  makeCategorical();
  updateTFunc();
  updateVR(colorTF, opacityTF, true);
});
