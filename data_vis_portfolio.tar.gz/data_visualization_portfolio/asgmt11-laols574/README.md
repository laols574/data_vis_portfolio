A11
------------

Author: Lauren Olson [laols574](mailto:laols574@email.arizona.edu)  
Date: 4/26/2020


## Notes
Visualization is rendering as necessitated in Google Chrome.


## Included files

* a11.js - This file contains all the javascript necessary to render the visualization
* d3.v5.js - This file contains D3.
* index.html - This is the HTML file which acts as a template for the visualization.
* volren.js - Javascript necessary for volume rendering.
* vtk.js - Javascript necessary for volume rendering.


## References
https://bl.ocks.org/denisemauldin/538bfab8378ac9c3a32187b4d7aed2c2
https://github.com/d3/d3-scale-chromatic

