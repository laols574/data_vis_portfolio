A09
------------

Author: Lauren Olson [laols574](mailto:laols574@email.arizona.edu)  
Date: 4/5/2020


## Notes
All four buttons and their respective renderings are rendering in Google Chrome.


## Included files

* a09.js - This file ccontains all of the functions required to create the visualization.
* index.html - This file creates the basic html layout for the visualization elements.
* flare.js - This file contains the large data set, which represents a tree-like file system.
* test-cases.js - This file contains the smaller sample tree data sets.
* solution-screenshots - This folder contains various screenshots of what the final tree structure is supposed to look like.


## References
* https://jalevine.bitbucket.io/csc444/assignments/2020/03/25/A09.html


