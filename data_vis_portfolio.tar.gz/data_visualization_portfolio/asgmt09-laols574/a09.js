//
// a09.js
// Template for CSC444 Assignment 09
// Joshua A. Levine <josh@email.arizona.edu
//
// This file provides the template code for A09, providing a skeleton
// for how to initialize and draw tree maps
//

/*
 a09.js
 CSC444 Assignment 09
 Lauren Olson laols574@email.arizona.edu
 This file includes all functionality for
 creating and coloring the data for the requested
 visualization. There are functions for creating the various
 scales as well as a function for creating the vis as a whole.
*/

////////////////////////////////////////////////////////////////////////
// Global variables for the dataset

// HINT: Start with one of the smaller test datesets included in
// test-cases.js instead of the larger tree in flare.js
//let data = test_1;
//let data = test_2;
let data = flare;



////////////////////////////////////////////////////////////////////////
// Tree related helper functions

function setTreeSize(tree)
{
  if (tree.children !== undefined) {
    let size = 0;
    for (let i=0; i<tree.children.length; ++i) {
      size += setTreeSize(tree.children[i]);
    }
    tree.size = size;
  }
  if (tree.children === undefined) {
    // do nothing, tree.size is already defined for leaves
  }
  return tree.size;
};

function setTreeCount(tree)
{
  if (tree.children !== undefined) {
    let count = 0;
    for (let i=0; i<tree.children.length; ++i) {
      count += setTreeCount(tree.children[i]);
    }
    tree.count = count;
  }
  if (tree.children === undefined) {
    tree.count = 1;
  }
  return tree.count;
}

m = -1;
function setTreeDepth(tree, depth)
{
  tree.depth = depth;
  if(m < depth){m = depth;}
  //set tree.childrens' depth based on tree's depth
  if (tree.children !== undefined) {
    for (let i=0; i<tree.children.length; i++) {
      setTreeDepth(tree.children[i], depth + 1);
    }
  }
  if (tree.children === undefined) {
    //they should already be defined
  }
  return tree.depth;
}


// Initialize the size, count, and depth variables within the tree
setTreeSize(data);
setTreeCount(data);
let maxDepth = setTreeDepth(data, 0);
maxDepth = m;

////////////////////////////////////////////////////////////////////////
// Main Code for the Treemapping Technique
/*
 setRectangles
 @param - rect - the rect which is going to be drawn on, the base rectangle
 @param - tree - the object which represents the data in a tree-like form
 @param - attrFun - this function decides whether or not the attribute is size or count
 @param - best - this paramater represents whether or not the algorithm should draw rectangles
  based on depth or whether or not the inner rectangles will fit well

  This function is resposible for defining the x and y coordinates which define the
  shape of all of the rectangles. It works recursively through the tree.
*/
function setRectangles(rect, tree, attrFun, best)
{
  tree.rect = rect;
  if (tree.children !== undefined) {
    let cumulativeSizes = [0];
    for (let i=0; i<tree.children.length; ++i) {
      cumulativeSizes.push(cumulativeSizes[i] + attrFun(tree.children[i]));
    }

    let rectWidth = rect.x2 - rect.x1;
    let rectHeight = rect.y2 - rect.y1;

    let border = .43*shrink(tree.depth);

    let xScale = d3.scaleLinear()
                  .domain([0, cumulativeSizes[cumulativeSizes.length-1]])
                  .range([rect.x1, rect.x2]);

    let yScale = d3.scaleLinear()
                  .domain([0, cumulativeSizes[cumulativeSizes.length-1]])
                  .range([rect.y1, rect.y2]);

    for (let i=0; i<tree.children.length; ++i) {
      if(i == 0){
        prev = 0;
        tree.curr = 0;
      }
      else{
        prev = attrFun(tree.children[i - 1]);
        tree.curr += prev;
      }
      curr = attrFun(tree.children[i]) + tree.curr;
      prev = tree.curr;

      let newRect = 0;

      if(best){
        if(rectWidth < rectHeight){
          newRect = { x1: rect.x1 + border, x2: rect.x2 - border, y1: yScale(prev) + border, y2: yScale(curr) - border};
        }
        else{
          newRect = { x1: xScale(prev) + border, x2: xScale(curr) - border, y1: rect.y1 + border, y2: rect.y2 - border};

        }
      }
      else{
        if(tree.depth % 2 == 1){
          newRect = { x1: rect.x1 + border, x2: rect.x2 - border, y1: yScale(prev) + border, y2: yScale(curr) - border};
        }
        else{
          newRect = { x1: xScale(prev) + border, x2: xScale(curr) - border, y1: rect.y1 + border, y2: rect.y2 - border};

        }

      }
      setRectangles(newRect, tree.children[i], attrFun, best);

    }
  }
}

// initialize the tree map
let winWidth = window.innerWidth;
let winHeight = window.innerHeight;

// compute the rectangles for each tree node
setRectangles(
  {x1: 0, y1: 0, x2: winWidth, y2: winHeight}, data,
  function(t) { return t.size; }
);

// make a list of all tree nodes;
function makeTreeNodeList(tree, lst)
{
  lst.push(tree);
  if (tree.children !== undefined) {
    for (let i=0; i<tree.children.length; ++i) {
      makeTreeNodeList(tree.children[i], lst);
    }
  }
}

let treeNodeList = [];
makeTreeNodeList(data, treeNodeList);


////////////////////////////////////////////////////////////////////////
// Visual Encoding portion

// d3 selection to draw the tree map
let gs = d3.select("#svg")
           .attr("width", winWidth)
           .attr("height", winHeight)
           .selectAll("g")
           .data(treeNodeList)
           .enter()
           .append("g");

function colorFill(d) {
   let m = d3.scaleLinear()
         .domain([maxDepth, 0])
         .range(["lightblue", "darkblue"])
         .interpolate(d3.interpolateHcl);

   return m(d.depth);
}


function shrink(d) {

   let m = d3.scaleLinear()
         .domain([0, maxDepth])
         .range([1, .2]);

   return m(d);
}

function setAttrs(sel) {
  sel.attr("width", function(treeNode) {
      width = treeNode.rect.x2 - treeNode.rect.x1
      return width;
    })
     .attr("height", function(treeNode) {
       height = treeNode.rect.y2 - treeNode.rect.y1;
       return height;
     })
     .attr("x", function(treeNode) { return treeNode.rect.x1;})
     .attr("y", function(treeNode) { return treeNode.rect.y1; })
     .attr("fill", function(treeNode) { return colorFill(treeNode);})
     .attr("stroke", function(treeNode) { return "black";})
     .attr("stroke-width", .075)
     .attr("title", function(treeNode) {
        return treeNode.name;
     });
}

gs.append("rect").call(setAttrs);



////////////////////////////////////////////////////////////////////////
// Callbacks for buttons

d3.select("#size").on("click", function() {
  setRectangles(
    {x1: 0, x2: winWidth, y1: 0, y2: winHeight}, data,
    function(t) { return t.size; }, false
  );
  d3.selectAll("rect").transition().duration(1000).call(setAttrs);
});

d3.select("#count").on("click", function() {
  setRectangles(
    {x1: 0, x2: winWidth, y1: 0, y2: winHeight}, data,
    function(t) { return t.count; }, false
  );
  d3.selectAll("rect").transition().duration(1000).call(setAttrs);
});


//these two were added my me
d3.select("#best-size").on("click", function() {
  setRectangles(
    {x1: 0, x2: winWidth, y1: 0, y2: winHeight}, data,
    function(t) { return t.size; }, true
  );
  d3.selectAll("rect").transition().duration(1000).call(setAttrs);
});

d3.select("#best-count").on("click", function() {
  setRectangles(
    {x1: 0, x2: winWidth, y1: 0, y2: winHeight}, data,
    function(t) { return t.count; }, true
  );
  d3.selectAll("rect").transition().duration(1000).call(setAttrs);
});
