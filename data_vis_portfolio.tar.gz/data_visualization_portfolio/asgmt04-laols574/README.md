 A04
------------

Author: Lauren Olson [laols574](mailto:laols574@email.arizona.edu)  
Date: 2/16/20


## Notes
All four visualizations were rendering properly on Google Chrome. 


## Included files

* index.html - this file contains all HTML for the plots
* d3.v5.js - contains all the functions for d3
* calvinScores.js - contains small student scores data set
* ukDriverFatalities.js - contains a data set regarding UK Driver Fatalities
* a04.js - contains all javascript functions in the project




## References
https://cscheid.net/courses/fall-2019/csc444/lectures/lecture4/iteration_8.html

https://www.sitepoint.com/a-beginners-guide-to-data-binding-in-d3-js/

