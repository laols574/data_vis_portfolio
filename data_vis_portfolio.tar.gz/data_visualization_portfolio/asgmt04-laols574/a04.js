/*
 a04.js
 CSC444 Assignment 04
 Lauren Olson <laols574@email.arizona.edu
 This file includes all functions necessary to
 create the four requested visualizations for this
 assignment. It includes three helper functions from
 the L04’s iteration_8.js as well as recreations
 of the code there as well as code that acts as a
 recreation of one of the visualizations from last week
*/


/*
 Script to clamp
 This function adds the utility to round down values
 and also scale them based on the ukDriverFatalities data
*/
function clamp(v) {
  return Math.floor(Math.max(0, Math.min(255, v)));
}

/*
 Script to rgb
 This function adds the utility to change integer values
 into a rgb string to feed into a d3 attr function
*/

function rgb(r, g, b) {
  return "rgb(" + r + "," + g + "," + b + ")";
}

/*
 Script for color
 This function also scales data values to color
 based on the ukDriverFatalities data
*/
function color(count){
  var amount = (2500 - count) / 2500 * 255;
  var s = clamp(amount), s2 = clamp(amount / 2 + 127), s3 = clamp(amount / 2 + 127);

  return rgb(s, s2, s3);
}
/*
 Script to create a visualization 1
 First, this script identifies the first svg
 element via it's id. Next, it creates the required
 variables. This function utilizes d3 functions to
 create elements through the enter() function. Data is
 bound to the svg element, attributes are chosen, and
 the proper elements are appended to the svg canvas.
 This is the first graph from L04’s iteration_8.js
*/

function createVis1(){
  let data = ukDriverFatalities;
  let vis1 = d3.select("#vis1")
      .append("svg")
      .attr("id", "chart1")
      .attr("width", "600")
      .attr("height", "300");

    vis1.selectAll("whatever")
          .data(data)
          .enter()
          .append("rect")
          .attr("width" ,function() { return Math.ceil(600 / (1984 - 1969 + 1)); })
          .attr("height" ,function() { return Math.ceil(300 / 12); })
          .attr("x" ,function(d) { return Math.ceil(600 / (1984 - 1969 + 1)) * (d.year - 1969); })
          .attr("y", function(d) { return Math.ceil(300 / 12) * (11 - d.month); })
          .attr("fill" , function(d) { return color(d.count);});
}

/*
 Script to create a visualization 1
 First, this script identifies the first svg
 element via it's id. Next, it creates the required
 variables. This function utilizes d3 functions to
 create elements through the enter() function. Data is
 bound to the svg element, attributes are chosen, and
 the proper elements are appended to the svg canvas.
 This is the second graph from L04’s iteration_8.js
 The main difference between this graph and the
 previous is the use of circle elements and the
 rectangle in the background to act as background color.
*/

function createVis2(){
  let data = ukDriverFatalities;
  let vis2 = d3.select("#vis2")
      .append("svg")
      .attr("id", "chart2")
      .attr("width", "600")
      .attr("height", "300");

      vis2.append("rect")
          .attr( "width","100%" )
          .attr( "height","100%")
          .attr( "fill","lavenderblush" ) ;

    vis2.selectAll("whatever")
          .data(data)
          .enter()
          .append("circle")
          .attr("cx", function(d){ return Math.ceil(600 / (1984 - 1969 + 1)) * (d.year - 1969 + 0.5); })
          .attr("cy", function(d){ return Math.ceil(300 / 12) * (11 - d.month + 0.5);  })
          .attr("r", function(d){ return d.count / 500 * 3 })
          .attr("stroke", function(d){ return "white"})
          .attr("fill",  "blue");
}
/*
 Script to create a visualization 3
 First, this script identifies the first svg
 element via it's id. Next, it creates the required
 variables. This function utilizes d3 functions to
 create elements through the enter() function. Data is
 bound to the svg element, attributes are chosen, and
 the proper elements are appended to the svg canvas.
 This is the third graph from L04’s iteration_8.js
*/

function createVis3(){
  let data = ukDriverFatalities;
  let vis3 = d3.select("#vis3")
      .append("svg")
      .attr("id", "chart3")
      .attr("width", "600")
      .attr("height", "300");

    vis3.append("rect")
        .attr( "width","100%" )
        .attr( "height","100%")
        .attr( "fill","lavenderblush" ) ;

    let len = data.length;


    vis3.selectAll("whatever")
          .data(data)
          .enter()
          .append("rect")
          .attr("width", function(d){ return Math.ceil(600/len) })
          .attr("height", function(d){ return d.count / 2500 * 300 })
          .attr("x", function(d, i){ return i*600 /len })
          .attr("y", function(d){ return 300 - (d.count / 2500 * 300) })
          .attr("fill",  "darkgrey");

}

/*
 Script to create a visualization 4
 First, this script identifies the first svg
 element via it's id. Next, it creates the required
 variables. This function utilizes d3 functions to
 create elements through the enter() function. Data is
 bound to the svg element, attributes are chosen, and
 the proper elements are appended to the svg canvas.
 This is the second visualization from the last assignment,
 simply using d3
*/

function createVis4(){
  let d = scores;
  let vis4 = d3.select("#vis4")
              .append("svg")
              .attr("id", "chart4")
              .attr("width", "500")
              .attr("height", "500");

  vis4.selectAll("whatever")
        .data(d)
        .enter()
        .append("circle")
        .attr("cx", function(d){ return ((d.ACT*500)/36) - 50 })
        .attr("cy", function(d){ return 500 - ((d.GPA*500)/4) + 50})
        .attr("r", function(d){return d.SATV*.01})
        .attr("fill", function(d){ return rgb(d.SATM/800, d.SATM/800, d.SATM/800)})
        .attr("fill-opacity", ".5");
}
